#include <iostream>
using namespace std;

int main() {
    int rows, cols;
    cout << "Enter rows: ";
    cin >> rows;
    cout << "Enter columns: ";
    cin >> cols;

    int **arr = new int*[rows];

    for(int i = 0; i < rows; i++)
        arr[i] = new int[cols];

    cout << "\nEnter matrix elements:\n";
    for(int i = 0; i < rows; i++)
        for(int j = 0; j < cols; j++)
            cin >> arr[i][j];

    cout << "\nMatrix:\n";
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++)
            cout << arr[i][j] << " ";
        cout << endl;
    }

    // Free memory
    for(int i = 0; i < rows; i++)
        delete[] arr[i];

    delete[] arr;

    return 0;
}
