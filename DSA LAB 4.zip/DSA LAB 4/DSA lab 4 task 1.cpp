#include <iostream>
using namespace std;

class Mobile {
public:
    string brand;
    int unitsOnHand;
    double price;

    Mobile() {}

    Mobile(string b, int u, double p) {
        brand = b;
        unitsOnHand = u;
        price = p;
    }

    void display() {
        cout << "Brand: " << brand << endl;
        cout << "Units: " << unitsOnHand << endl;
        cout << "Price: " << price << endl;
        cout << "----------------------" << endl;
    }
};
class Node {
public:
    Mobile data;
    Node* next;

    Node(Mobile m) {
        data = m;
        next = NULL;
    }
};

class Store {
public:
    Node* head;

    Store() {
        head = NULL;
    }
    void insertStart(Mobile m) {
        Node* newNode = new Node(m);
        newNode->next = head;
        head = newNode;
    }
    void insertEnd(Mobile m) {
        Node* newNode = new Node(m);
        if (head == NULL) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL)
            temp = temp->next;

        temp->next = newNode;
    }
    void insertAfter(int pos, Mobile m) {
        Node* temp = head;
        for (int i = 1; i < pos && temp != NULL; i++) {
            temp = temp->next;
        }
        if (temp == NULL) return;

        Node* newNode = new Node(m);
        newNode->next = temp->next;
        temp->next = newNode;
    }
    void deleteStart() {
        if (head == NULL) return;
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    void deleteEnd() {
        if (head == NULL) return;

        if (head->next == NULL) {
            delete head;
            head = NULL;
            return;
        }

        Node* temp = head;
        while (temp->next->next != NULL)
            temp = temp->next;

        delete temp->next;
        temp->next = NULL;
    }
    void deleteAt(int pos) {
        if (head == NULL) return;

        if (pos == 1) {
            deleteStart();
            return;
        }

        Node* temp = head;
        for (int i = 1; i < pos - 1 && temp != NULL; i++) {
            temp = temp->next;
        }

        if (temp == NULL || temp->next == NULL) return;

        Node* del = temp->next;
        temp->next = del->next;
        delete del;
    }
    void display() {
        Node* temp = head;
        while (temp != NULL) {
            temp->data.display();
            temp = temp->next;
        }
    }
};

int main() {
    Store s;

    s.insertEnd(Mobile("Samsung", 10, 50000));
    s.insertStart(Mobile("Apple", 5, 150000));
    s.insertAfter(1, Mobile("Infinix", 20, 30000));

    cout << "Mobiles List:\n";
    s.display();

    s.deleteStart();
    s.deleteEnd();
    s.deleteAt(1);

    cout << "\nAfter Deletions:\n";
    s.display();

    return 0;
}
