#include <iostream>
using namespace std;

class Profile {
public:
    int id, age;
    string name, gender, email, interest, dob;

    Profile() {}

    Profile(int i, string n, string g, int a, string e, string in, string d) {
        id = i;
        name = n;
        gender = g;
        age = a;
        email = e;
        interest = in;
        dob = d;
    }

    void display() {
        cout << "ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Gender: " << gender << endl;
        cout << "Age: " << age << endl;
        cout << "Email: " << email << endl;
        cout << "Interest: " << interest << endl;
        cout << "DOB: " << dob << endl;
        cout << "----------------------" << endl;
    }
};
class Node {
public:
    Profile data;
    Node* next;

    Node(Profile p) {
        data = p;
        next = NULL;
    }
};

class Portal {
public:
    Node* head;

    Portal() {
        head = NULL;
    }
    void InsertProfile(Profile p) {
        Node* newNode = new Node(p);
        if (head == NULL) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL)
            temp = temp->next;

        temp->next = newNode;
    }
    void UpdateProfile(int id) {
        Node* temp = head;
        while (temp != NULL) {
            if (temp->data.id == id) {
                cout << "Enter New Name: ";
                cin >> temp->data.name;
                cout << "Enter New Age: ";
                cin >> temp->data.age;
                return;
            }
            temp = temp->next;
        }
        cout << "Profile not found\n";
    }
    void DeleteProfile(string name) {
        if (head == NULL) return;

        if (head->data.name == name) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* temp = head;
        while (temp->next != NULL && temp->next->data.name != name)
            temp = temp->next;

        if (temp->next == NULL) return;

        Node* del = temp->next;
        temp->next = del->next;
        delete del;
    }
    void searchProfile(string name) {
        Node* temp = head;
        while (temp != NULL) {
            if (temp->data.name == name) {
                temp->data.display();
                return;
            }
            temp = temp->next;
        }
        cout << "Profile not found\n";
    }
    void Display() {
        Node* temp = head;
        while (temp != NULL) {
            temp->data.display();
            temp = temp->next;
        }
    }
};
int main() {
    Portal p;
    int choice;

    do {
        cout << "\n1.Add\n2.Update\n3.Delete\n4.Search\n5.Display\n6.Exit\n";
        cin >> choice;

        if (choice == 1) {
            int id, age;
            string name, gender, email, interest, dob;

            cout << "Enter ID Name Gender Age Email Interest DOB:\n";
            cin >> id >> name >> gender >> age >> email >> interest >> dob;

            p.InsertProfile(Profile(id, name, gender, age, email, interest, dob));
        }
        else if (choice == 2) {
            int id;
            cout << "Enter ID: ";
            cin >> id;
            p.UpdateProfile(id);
        }
        else if (choice == 3) {
            string name;
            cout << "Enter Name: ";
            cin >> name;
            p.DeleteProfile(name);
        }
        else if (choice == 4) {
            string name;
            cout << "Enter Name: ";
            cin >> name;
            p.searchProfile(name);
        }
        else if (choice == 5) {
            p.Display();
        }

    } while (choice != 6);

    return 0;
}
