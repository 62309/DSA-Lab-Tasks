#include <iostream>
using namespace std;

struct Node {
    float data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void insert(float value) {
    if (value < 0) {
        cout << "Invalid input!\n";
        return;
    }

    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        newNode->prev = NULL;
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

void calculate() {
    Node* temp = head;
    float total = 0, max = -1, min = 9999;
    int day = 1, maxDay = 1, minDay = 1;

    while (temp != NULL) {
        total += temp->data;

        if (temp->data > max) {
            max = temp->data;
            maxDay = day;
        }

        if (temp->data < min) {
            min = temp->data;
            minDay = day;
        }

        temp = temp->next;
        day++;
    }

    cout << "Total Rainfall: " << total << endl;
    cout << "Average: " << total / 7 << endl;
    cout << "Highest on Day " << maxDay << endl;
    cout << "Lowest on Day " << minDay << endl;
}

void after5th() {
    Node* temp = head;
    int count = 1;

    while (temp != NULL && count < 6) {
        temp = temp->next;
        count++;
    }

    if (temp != NULL)
        cout << "Rainfall after 5th: " << temp->data << endl;
}

int main() {
    float val;

    for (int i = 0; i < 7; i++) {
        cin >> val;
        insert(val);
    }

    calculate();
    after5th();

    return 0;
}
