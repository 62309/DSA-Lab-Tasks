#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

void addBeginning(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL)
        head->prev = newNode;

    head = newNode;
}

void addAfter45(int value) {
    Node* temp = head;

    while (temp != NULL && temp->data != 45) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "45 not found\n";
        return;
    }

    Node* newNode = new Node();
    newNode->data = value;

    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

void deleteBeginning() {
    if (head == NULL) return;

    Node* temp = head;
    head = head->next;

    if (head != NULL)
        head->prev = NULL;

    delete temp;
}

void deleteAfter45() {
    Node* temp = head;

    while (temp != NULL && temp->data != 45) {
        temp = temp->next;
    }

    if (temp == NULL || temp->next == NULL) {
        cout << "No node after 45\n";
        return;
    }

    Node* del = temp->next;
    temp->next = del->next;

    if (del->next != NULL)
        del->next->prev = temp;

    delete del;
}


void display() {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " <-> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

int main() {
    int n, val;
    cout << "Enter number of nodes: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> val;
        addBeginning(val);
    }

    display();

    addAfter45(99);
    display();

    deleteBeginning();
    display();

    deleteAfter45();
    display();

    return 0;
}
