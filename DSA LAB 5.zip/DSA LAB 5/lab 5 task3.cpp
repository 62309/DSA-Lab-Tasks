#include <iostream>
using namespace std;

struct Player {
    string name;
    int score;
    Player* prev;
    Player* next;
};

Player* head = NULL;
void addPlayer(string name, int score) {
    Player* newNode = new Player();
    newNode->name = name;
    newNode->score = score;

    if (head == NULL || score < head->score) {
        newNode->next = head;
        newNode->prev = NULL;

        if (head != NULL)
            head->prev = newNode;

        head = newNode;
        return;
    }

    Player* temp = head;
    while (temp->next != NULL && temp->next->score < score)
        temp = temp->next;

    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

void deletePlayer(string name) {
    Player* temp = head;

    while (temp != NULL && temp->name != name)
        temp = temp->next;

    if (temp == NULL) return;

    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    else
        head = temp->next;

    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    delete temp;
}

void display() {
    Player* temp = head;
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    }
}

void lowest() {
    if (head != NULL)
        cout << "Lowest: " << head->name << endl;
}


void sameScore(int s) {
    Player* temp = head;
    while (temp != NULL) {
        if (temp->score == s)
            cout << temp->name << endl;
        temp = temp->next;
    }
}

void backward(string name) {
    Player* temp = head;

    while (temp != NULL && temp->name != name)
        temp = temp->next;

    while (temp != NULL) {
        cout << temp->name << " ";
        temp = temp->prev;
    }
}

int main() {
    addPlayer("Ali", 70);
    addPlayer("Sara", 60);
    addPlayer("Ahmed", 70);

    display();
    lowest();
    sameScore(70);
    backward("Ahmed");

    return 0;
}
